// florian arsal bejte ekfu24/1 20240035
const firstName = "Tom";
const lastName = "Cruise";
const age = 61;
const city = "New York city";

console.log(`My name is ${firstName} ${lastName}. I am ${age} years old and I am from ${city}.`);
