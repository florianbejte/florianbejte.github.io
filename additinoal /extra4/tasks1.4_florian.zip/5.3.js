for (let i = 24; i >= -4; i--) {
    console.log(i);
}
