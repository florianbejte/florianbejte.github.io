// florian arsal bejte ekfu24/1 20240035

function check(number) {
    if (number % 2 === 0) {
        return "Even";
    } else {
        return "Odd";
    }
}

console.log(check(2));
console.log(check(17));
